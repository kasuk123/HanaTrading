export default class ConsultListPage {

}